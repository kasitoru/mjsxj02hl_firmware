#!/bin/sh

if [ ! -f dump.bin ]; then
    echo "Error: dump.bin file is missing!"
    exit
fi

dump_size=$(du -b -s dump.bin | cut -f 1)
if [ "$dump_size" -ne 16777216 ]; then
    echo "Error: dump.bin file is corrupted!"
    exit
fi

rm -f output.bin
dd if=uboot.bin > output.bin
dd if=dump.bin of=temp.bin bs=1k skip=256
dd if=temp.bin >> output.bin
rm -f temp.bin

